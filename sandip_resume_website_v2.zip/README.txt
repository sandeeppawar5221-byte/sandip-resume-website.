SANDIP PAWAR — RESUME WEBSITE

The site has been redesigned to match the approved light-blue / medium-dark navy portfolio concept.
Included:
- index.html — responsive static HTML website; resume content is present in the source
- assets/sandip-profile.png — your supplied portrait

Before publishing:
- Confirm the B.Pharmacy CGPA is 8.06 (the uploaded resume showed 8.09; the website uses your later correction).
- The resume does not list formal projects, so the Projects section labels these as interests, not completed projects.
- The site does not show your phone number or full address.

Netlify quick deployment:
1. Open https://app.netlify.com/drop and sign in.
2. Upload the complete unzipped website folder (keep index.html and assets together).
3. Netlify will provide a public link.

If the assignment requires GitHub + Vercel:
1. Upload index.html and the assets folder to a GitHub repository.
2. Import that repository into Vercel and deploy.
3. Open the live link and view page source; search for “Sandip Pawar”, “Education”, and “Supply Chain”.
